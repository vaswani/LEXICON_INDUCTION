package edu.berkeley.nlp.wordAlignment;

/**
 * A cache for trellises during training.
 */
public class TrainingCache {
  public void clear() { }
}
