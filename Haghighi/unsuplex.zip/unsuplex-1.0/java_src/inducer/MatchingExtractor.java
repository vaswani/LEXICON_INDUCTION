package inducer;

public interface MatchingExtractor {
	public int[] extractMatching(double[][] matchingPotentials);
}
