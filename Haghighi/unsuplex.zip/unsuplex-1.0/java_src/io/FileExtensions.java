package io;

public class FileExtensions {
	
	public static final String ALIGN_EXTENSION = "align";
	public static final String LEX_EXTENSION = "lex";
	public static final String DOMAIN_TAG_EXTENSION = "entags";
	public static final String CODOMAIN_TAG_EXTENSION = "estags";
	public static final String DOMAIN_TAG_MAP_EXTENSION = "entagmap";
	public static final String CODOMAIN_TAG_MAP_EXTENSION = "estagmap";
	public static final String DOMAIN_CORPUS_EXTENSION = "encorp";
	public static final String CODOMAIN_CORPUS_EXTENSION = "escorp";

}
