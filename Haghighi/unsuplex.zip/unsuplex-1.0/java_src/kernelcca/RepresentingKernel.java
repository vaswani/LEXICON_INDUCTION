package kernelcca;

public interface RepresentingKernel<T> extends Kernel<T>, VectorRepresenter<T> {

}
